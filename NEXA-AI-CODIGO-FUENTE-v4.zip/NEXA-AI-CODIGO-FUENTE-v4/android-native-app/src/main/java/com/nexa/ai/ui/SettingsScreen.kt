package com.nexa.ai.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexa.ai.BuildConfig
import com.nexa.ai.ui.theme.NexaAccent
import com.nexa.ai.ui.theme.LocalAccentColor
import com.nexa.ai.ui.theme.dynamicPrimaryColor
import com.nexa.ai.viewmodel.*

// ═══════════════════════════════════════════════════════════════
//  SETTINGS SCREEN — Clean Minimalist Redesign
// ═══════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    uiState: NexaUiState,
    isDarkTheme: Boolean,
    onBack: () -> Unit,
    onSetLanguage: (AppLanguage) -> Unit,
    onSetVoiceType: (VoiceType) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onClearChat: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onLogout: () -> Unit,
    onRequestLocation: () -> Unit = {},
    onToggleNotifications: () -> Unit = {},
    onToggleVolumeBoost: () -> Unit = {},
    onSetSpeechRate: (Float) -> Unit = {},
    onQuickAction: (String) -> Unit = {},
    onPreviewVoice: () -> Unit = {},
    onSetAccentColor: (Color) -> Unit = {},
    onExportSettings: () -> Unit = {},
    onImportSettings: () -> Unit = {}
) {
    // Standardized spacing measurement for uniformity — using adaptive system
    val sectionSpacing = AdaptiveDimens.sectionSpacing()
    val internalSpacing = AdaptiveDimens.spacingMd()

    val effectiveAccent = LocalAccentColor.current

    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.08f, targetValue = 0.15f,
        animationSpec = infiniteRepeatable(tween(4000, easing = EaseInOut), RepeatMode.Reverse),
        label = "glowAlpha"
    )

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(modifier = Modifier.size(300.dp).offset((-50).dp, (-100).dp).blur(120.dp).background(effectiveAccent.copy(alpha = glowAlpha)))
        Box(modifier = Modifier.size(250.dp).offset(200.dp, 500.dp).blur(120.dp).background(Color(0xFF0066FF).copy(alpha = glowAlpha * 0.5f)))

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            NexaStrings.get("settings", uiState.language).uppercase(),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            letterSpacing = 4.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    },
                    navigationIcon = {
                        MinimalIconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", modifier = Modifier.size(18.dp))
                        }
                    },

                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            var sectionsVisible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { sectionsVisible = true }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = AdaptiveDimens.horizontalPadding(), vertical = AdaptiveDimens.verticalPadding()),
                verticalArrangement = Arrangement.spacedBy(sectionSpacing)
            ) {

                // ── Profile Card ──
                StaggeredFadeIn(visible = sectionsVisible, index = 0) {
                    FuturisticCard {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            // Avatar
                            Box(modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(effectiveAccent, effectiveAccent.copy(alpha = 0.6f)))), contentAlignment = Alignment.Center) {
                                if (uiState.user.isLoggedIn) {
                                    Text(uiState.user.displayName.take(1).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                } else {
                                    Icon(Icons.Default.Person, null, modifier = Modifier.size(22.dp), tint = Color.Black)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("NEXA PRO", fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = effectiveAccent)
                                if (uiState.user.isLoggedIn) {
                                    Text(uiState.user.email, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                } else {
                                    Surface(onClick = onNavigateToLogin, shape = RoundedCornerShape(8.dp), color = effectiveAccent.copy(alpha = 0.08f)) {
                                        Text(NexaStrings.get("login", uiState.language), modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = effectiveAccent)
                                    }
                                }
                            }
                            Box(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(effectiveAccent.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.FlashOn, null, modifier = Modifier.size(16.dp), tint = effectiveAccent)
                            }
                        }
                    }
                }

                // ── Language ──
                StaggeredFadeIn(visible = sectionsVisible, index = 1) {
                    Column(verticalArrangement = Arrangement.spacedBy(internalSpacing)) {
                        SectionLabel(NexaStrings.get("language", uiState.language).uppercase())
                        FuturisticCard {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(AppLanguage.SPANISH to "🇪🇸  Español", AppLanguage.ENGLISH to "🇺🇸  English").forEach { (lang, label) ->
                                    val selected = uiState.language == lang
                                    FuturisticPill(label = label, selected = selected, accent = effectiveAccent, modifier = Modifier.weight(1f), onClick = { onSetLanguage(lang) })
                                }
                            }
                        }
                    }
                }

                // ── Voice ──
                StaggeredFadeIn(visible = sectionsVisible, index = 2) {
                    Column(verticalArrangement = Arrangement.spacedBy(internalSpacing)) {
                        SectionLabel(NexaStrings.get("voice", uiState.language).uppercase())
                        FuturisticCard {
                            // Sub-label for consistency
                            Text(NexaStrings.get("male_label", uiState.language).uppercase(), fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, color = effectiveAccent.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                VoiceType.entries.filter { it.name.startsWith("MALE") }.forEach { voice ->
                                    val selected = uiState.voiceType == voice
                                    VoiceCard(voice = voice, label = NexaStrings.get(voice.name.lowercase(), uiState.language), selected = selected, modifier = Modifier.weight(1f), onClick = { onSetVoiceType(voice) })
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(NexaStrings.get("female_label", uiState.language).uppercase(), fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, color = effectiveAccent.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                VoiceType.entries.filter { it.name.contains("FEMALE") }.forEach { voice ->
                                    val selected = uiState.voiceType == voice
                                    VoiceCard(voice = voice, label = NexaStrings.get(voice.name.lowercase(), uiState.language), selected = selected, modifier = Modifier.weight(1f), onClick = { onSetVoiceType(voice) })
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            // Voice preview button
                            Surface(
                                onClick = { onPreviewVoice() },
                                shape = RoundedCornerShape(12.dp),
                                color = effectiveAccent.copy(alpha = 0.08f),
                                border = BorderStroke(0.5.dp, effectiveAccent.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp), tint = effectiveAccent)
                                    Text(
                                        NexaStrings.get("preview_voice", uiState.language),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = effectiveAccent
                                    )
                                }
                            }
                        }
                    }
                }

                // ── Appearance (Theme + Accent Color) ──
                StaggeredFadeIn(visible = sectionsVisible, index = 3) {
                    Column(verticalArrangement = Arrangement.spacedBy(internalSpacing)) {
                        SectionLabel(NexaStrings.get("theme", uiState.language).uppercase())
                        FuturisticCard {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                ThemeOption(label = NexaStrings.get("dark", uiState.language), emoji = "\uD83C\uDF19", previewTop = Color(0xFF1A1A24), previewBottom = Color(0xFF0D0D12), selected = uiState.themeMode == ThemeMode.DARK, onClick = { onSetThemeMode(ThemeMode.DARK) }, modifier = Modifier.weight(1f))
                                ThemeOption(label = NexaStrings.get("light", uiState.language), emoji = "\u2600\uFE0F", previewTop = Color(0xFFF8F9FC), previewBottom = Color(0xFFFFFFFF), selected = uiState.themeMode == ThemeMode.LIGHT, onClick = { onSetThemeMode(ThemeMode.LIGHT) }, modifier = Modifier.weight(1f))
                                ThemeOption(label = NexaStrings.get("system", uiState.language), emoji = "\u2699\uFE0F", previewTop = Color(0xFF1A1A24), previewBottom = Color(0xFFF8F9FC), selected = uiState.themeMode == ThemeMode.SYSTEM, onClick = { onSetThemeMode(ThemeMode.SYSTEM) }, isSystem = true, modifier = Modifier.weight(1f))
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(NexaStrings.get("accent_color", uiState.language).uppercase(), fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, color = effectiveAccent.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                val accentRow1 = listOf(Color(0xFF00F5A0) to "Emerald", Color(0xFF00B4D8) to "Ocean", Color(0xFF7C6AFF) to "Violet", Color(0xFFFF6B6B) to "Coral")
                                val accentRow2 = listOf(Color(0xFFFFB800) to "Amber", Color(0xFFFF00E5) to "Magenta", Color(0xFF00E5FF) to "Cyan", Color(0xFF8B5CF6) to "Purple")
                                listOf(accentRow1, accentRow2).forEach { row ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                        row.forEach { (color, name) ->
                                            val selected = effectiveAccent.value == color.value
                                            Surface(
                                                onClick = { onSetAccentColor(color) },
                                                shape = RoundedCornerShape(8.dp),
                                                color = color.copy(alpha = if (selected) 1f else 0.2f),
                                                border = if (selected) BorderStroke(1.5.dp, Color.White.copy(alpha = 0.7f)) else BorderStroke(0.5.dp, color.copy(alpha = 0.3f)),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
                                                    Text(name, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }







                // ── Danger Zone ──
                StaggeredFadeIn(visible = sectionsVisible, index = 10) {
                    Column(verticalArrangement = Arrangement.spacedBy(internalSpacing)) {
                        SectionLabel(NexaStrings.get("danger_zone", uiState.language).uppercase(), color = MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
                        FuturisticCard {
                            DangerButton(icon = Icons.Default.Delete, label = NexaStrings.get("clear_chat", uiState.language), onClick = onClearChat)
                            if (uiState.user.isLoggedIn) {
                                Spacer(modifier = Modifier.height(12.dp))
                                DangerButton(icon = Icons.AutoMirrored.Filled.ExitToApp, label = NexaStrings.get("logout", uiState.language), subtitle = uiState.user.email, onClick = onLogout)
                            }
                        }
                    }
                }

                // ── About ──
                StaggeredFadeIn(visible = sectionsVisible, index = 13) {
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.width(40.dp).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f), Color.Transparent))))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(NexaStrings.get("about_version", uiState.language), fontSize = 9.sp, fontWeight = FontWeight.Medium, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  STANDARD COMPONENTS
// ═══════════════════════════════════════════════════════════════

@Composable
private fun StaggeredFadeIn(visible: Boolean, index: Int, durationMs: Int = 450, staggerMs: Int = 80, content: @Composable () -> Unit) {
    val animVisibleState = remember { MutableTransitionState(false) }
    animVisibleState.targetState = visible
    AnimatedVisibility(visibleState = animVisibleState, enter = fadeIn(tween(durationMs, delayMillis = index * staggerMs)) + slideInVertically(tween(durationMs, delayMillis = index * staggerMs), initialOffsetY = { it / 12 }), exit = fadeOut()) { content() }
}

@Composable
private fun SectionLabel(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)) {
    Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = color, modifier = Modifier.padding(start = 4.dp))
}

@Composable
private fun FuturisticCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.60f), border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(18.dp)) { content() }
    }
}

@Composable
private fun FuturisticPill(label: String, selected: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
    Surface(modifier = modifier.scale(scale).pointerInput(Unit) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }) }, shape = RoundedCornerShape(12.dp), color = if (selected) accent.copy(alpha = 0.10f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f), border = if (selected) BorderStroke(1.5.dp, accent.copy(alpha = 0.40f)) else BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))) {
        Box(modifier = Modifier.fillMaxWidth().drawBehind { if (selected) drawRoundRect(Brush.linearGradient(listOf(accent.copy(alpha = 0.08f), Color.Transparent)), cornerRadius = CornerRadius(12.dp.toPx()), size = size) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Text(label, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) accent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.50f))
        }
    }
}

@Composable
private fun VoiceCard(voice: VoiceType, label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = LocalAccentColor.current
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.93f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
    val infiniteTransition = rememberInfiniteTransition()
    val wavePhase by infiniteTransition.animateFloat(0f, 2f * Math.PI.toFloat(), infiniteRepeatable(tween(1200, easing = LinearEasing)))
    Surface(modifier = modifier.scale(scale).pointerInput(Unit) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }) }, shape = RoundedCornerShape(14.dp), color = if (selected) accent.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f), border = if (selected) BorderStroke(1.5.dp, accent.copy(alpha = 0.40f)) else BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(modifier = Modifier.size(34.dp).clip(CircleShape).background(if (selected) accent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, modifier = Modifier.size(16.dp), tint = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
            }
            Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) accent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), textAlign = TextAlign.Center)
            if (selected) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.height(8.dp)) {
                    repeat(5) { i ->
                        val barHeight = (4 + 4 * kotlin.math.sin(wavePhase.toDouble() + i * 0.8).toFloat()).dp
                        Box(modifier = Modifier.width(2.dp).height(barHeight).clip(RoundedCornerShape(1.dp)).background(accent.copy(alpha = 0.7f)))
                    }
                }
            } else { Spacer(modifier = Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun RowScope.ThemeOption(label: String, emoji: String, previewTop: Color, previewBottom: Color, selected: Boolean, onClick: () -> Unit, isSystem: Boolean = false, modifier: Modifier = Modifier) {
    val accent = LocalAccentColor.current
    val haptic = LocalHapticFeedback.current
    Surface(modifier = modifier.clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }, shape = RoundedCornerShape(14.dp), color = if (selected) accent.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f), border = if (selected) BorderStroke(1.5.dp, accent.copy(alpha = 0.40f)) else BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.size(44.dp, 30.dp).clip(RoundedCornerShape(6.dp)).background(Brush.verticalGradient(listOf(previewTop, previewBottom)))) {
                if (isSystem) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF1A1A24)))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFF8F9FC)))
                    }
                }
            }
            Text("$emoji $label", fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) accent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun FuturisticSwitch(checked: Boolean, onCheckedChange: () -> Unit) {
    val accent = LocalAccentColor.current
    Surface(onClick = onCheckedChange, shape = RoundedCornerShape(12.dp), color = if (checked) accent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), border = BorderStroke(1.5.dp, if (checked) accent.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)), modifier = Modifier.size(46.dp, 24.dp)) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart) {
            Box(modifier = Modifier.padding(3.dp).size(18.dp).clip(CircleShape).background(if (checked) accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)))
        }
    }
}

@Composable
private fun DangerButton(icon: ImageVector, label: String, subtitle: String? = null, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.error.copy(alpha = 0.05f), border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.15f)), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.error.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
            }
            Column {
                Text(label, color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (subtitle != null) { Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)) }
            }
        }
    }
}

@Composable
private fun MinimalIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f), border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)), modifier = Modifier.size(40.dp)) {
        Box(contentAlignment = Alignment.Center) {
            CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)) { content() }
        }
    }
}
