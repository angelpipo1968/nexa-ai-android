package com.nexa.ai.viewmodel.usecase

import com.nexa.ai.BuildConfig
import com.nexa.ai.data.ChatMessage
import com.nexa.ai.data.NexaRepository
import com.nexa.ai.data.StreamEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ChatUseCase — Handles AI chat interaction logic, extracted from NexaViewModel.
 *
 * Manages:
 * - Sending messages to the AI API via NexaRepository
 * - Tracking loading state and errors
 * - Accumulating streaming responses
 * - Exposing chat state as a reactive StateFlow
 *
 * The ViewModel observes [state] and syncs with its own UI state.
 */
@Singleton
class ChatUseCase @Inject constructor(
    private val repository: NexaRepository
) {

    data class ChatMessageEntry(
        val user: String,
        val ai: String
    )

    data class ChatState(
        val isLoading: Boolean = false,
        val error: String? = null,
        val messages: List<ChatMessageEntry> = emptyList(),
        val currentStreamingText: String = ""
    )

    private val _state = MutableStateFlow(ChatState())
    val state: StateFlow<ChatState> = _state.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Configuration — set by ViewModel before sending
    var baseUrl: String = BuildConfig.API_BASE_URL
    var systemPrompt: String = ""
    var groqApiKey: String? = null
    var useLocalLLM: Boolean = false
    var localLlmBaseUrl: String = "http://192.168.1.50:4000"
    var localVisionModel: String = "vision"
    var localChatModel: String = "qwen"
    var maxTokens: Int = 4096

    // Message history for API context
    private val messageHistory = mutableListOf<ChatMessage>()

    /**
     * Send a user message to the AI and process the streaming response.
     *
     * @param text The user's message content
     * @param viewModelScope The ViewModel's coroutine scope for collecting the flow
     * @param extraContext Optional context (e.g., web search results) to inject
     */
    fun sendMessage(text: String, viewModelScope: CoroutineScope, extraContext: String? = null) {
        // Add user message to history if not already there (prevents duplicates during regenerate)
        if (messageHistory.lastOrNull()?.content != text) {
            messageHistory.add(ChatMessage("user", text))
        }

        val finalPrompt = if (!extraContext.isNullOrBlank()) {
            "[CONTEXT: $extraContext]\n\nUSER MESSAGE: $text"
        } else {
            text
        }

        _state.update { it.copy(isLoading = true, error = null, currentStreamingText = "") }

        viewModelScope.launch {
            try {
                val messages = buildMessageList().toMutableList()
                // Replace the last user message with the contextual one for the API call
                if (messages.isNotEmpty() && messages.last().role == "user") {
                    messages[messages.size - 1] = ChatMessage("user", finalPrompt)
                }

                val url = determineBaseUrl()

                repository.sendMessage(
                    messages = messageHistory,
                    baseUrl = url
                ).collect { event ->
                    when (event) {
                        is StreamEvent.Text -> {
                            android.util.Log.d("ChatUseCase", "Received text chunk: ${event.text}")
                            _state.update { current ->
                                current.copy(currentStreamingText = current.currentStreamingText + event.text)
                            }
                        }
                        is StreamEvent.Done -> {
                            android.util.Log.d("ChatUseCase", "Stream DONE. Final text length: ${_state.value.currentStreamingText.length}")
                            val finalText = _state.value.currentStreamingText
                            if (finalText.isNotBlank()) {
                                messageHistory.add(ChatMessage("assistant", finalText))
                                _state.update { current ->
                                    current.copy(
                                        isLoading = false,
                                        currentStreamingText = "",
                                        messages = current.messages + ChatMessageEntry(
                                            user = text,
                                            ai = finalText
                                        )
                                    )
                                }
                            } else {
                                _state.update { it.copy(isLoading = false, currentStreamingText = "") }
                            }
                        }
                        is StreamEvent.Error -> {
                            _state.update { it.copy(isLoading = false, error = event.message) }
                        }
                        is StreamEvent.AuthExpired -> {
                            _state.update { it.copy(isLoading = false, error = "auth_expired") }
                        }
                        is StreamEvent.Provider -> {
                            // Provider info, can be used for debugging
                        }
                    }
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
                android.util.Log.e("ChatUseCase", "Error sending message: ${e.message}", e)
            }
        }
    }

    /**
     * Re-trigger the last user message to get a new AI response.
     */
    fun regenerateResponse(viewModelScope: CoroutineScope) {
        val lastUserMsg = messageHistory.lastOrNull { it.role == "user" }?.content ?: return
        
        // Remove the last assistant message from history
        if (messageHistory.lastOrNull()?.role == "assistant") {
            messageHistory.removeAt(messageHistory.size - 1)
        }
        
        // Remove the last entry from the state messages list
        _state.update { current ->
            if (current.messages.isNotEmpty()) {
                current.copy(messages = current.messages.dropLast(1))
            } else current
        }
        
        sendMessage(lastUserMsg, viewModelScope)
    }

    /**
     * Clear chat history and reset state.
     */
    fun clearChat() {
        messageHistory.clear()
        _state.update { ChatState() }
    }

    /**
     * Build the message list for the API request, including system prompt.
     */
    private fun buildMessageList(): List<ChatMessage> {
        val messages = mutableListOf<ChatMessage>()
        // System prompt is handled by NexaRepository via the systemPrompt parameter
        messages.addAll(messageHistory)
        return messages
    }

    /**
     * Determine the base URL for the API request.
     * Priority: Groq API > Local LiteLLM > Default server.
     */
    private fun determineBaseUrl(): String {
        return if (!groqApiKey.isNullOrBlank()) {
            "https://api.groq.com/openai/v1"
        } else if (useLocalLLM) {
            localLlmBaseUrl
        } else {
            baseUrl
        }
    }

    /**
     * Send a vision request to local LiteLLM with an image and text prompt.
     * Uses OpenAI-compatible chat completions with multimodal content.
     *
     * @param base64Image Base64-encoded image data (raw, without data URI prefix)
     * @param mimeType Image MIME type, e.g. "image/jpeg"
     * @param question Text prompt about the image
     * @param viewModelScope Coroutine scope for the request
     * @param onResult Callback with the assistant's response text or null on error
     */
    fun sendVisionMessage(
        base64Image: String,
        mimeType: String,
        question: String,
        viewModelScope: CoroutineScope,
        onResult: (String?) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val result = repository.sendLiteLLMVisionRequest(
                    baseUrl = localLlmBaseUrl,
                    base64Image = base64Image,
                    mimeType = mimeType,
                    question = question,
                    model = localVisionModel
                )
                onResult(result)
            } catch (e: Exception) {
                android.util.Log.e("ChatUseCase", "Vision message error: ${e.message}", e)
                onResult(null)
            }
        }
    }

    /**
     * Add a message to the history without triggering an API call.
     * Used for restoring state or injecting system messages.
     */
    fun addMessageToHistory(role: String, content: String) {
        messageHistory.add(ChatMessage(role, content))
    }

    /**
     * Get the current message history size.
     */
    fun historySize(): Int = messageHistory.size
}
